
LCD and Keypad Library
======================

by Andy Gock

for DFRobot LCD Keypad Arduino Shield

Blog post:
http://micro.gock.net/2013/02/arduino-library-for-df-robot-16x2-lcd-keypad-shield/

Compatible Shield:
http://www.dfrobot.com/index.php?route=product/product&product_id=51

Installation
------------

(Arduino 1.x) If adding library for the first time, in your Arduino workspace, open the "libraries" directory, create a new directory "DFR_LCD_Keypad". If updating, just replace the files already in there.

Add contents of this repository inside there.

Open the example file for a demo.
